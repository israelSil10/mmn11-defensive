#include <iostream>
#include "Video.h"
#include "Media.h"

class Video : public Media
{
	void display() { std::cout << "Displaying video" << std::endl; }
};