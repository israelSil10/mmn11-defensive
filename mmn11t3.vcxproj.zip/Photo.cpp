#include <iostream>
#include "Photo.h"

class Photo : public Media
{
	void display() { std::cout << "Displaying photo" << std::endl; }
};
