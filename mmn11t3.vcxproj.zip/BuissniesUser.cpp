#include <iostream>
#include "buissniesUser.h"
#include "user.h"
#include "Message.h"


void sendMsg(User*, Message)
{

}