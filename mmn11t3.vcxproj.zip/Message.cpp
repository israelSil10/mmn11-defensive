#include <list>
#include <iostream>
#include "Message.h"

class Message
{
	std::string text;

public:
	std::string getText()
	{
		std::cout << "hi" << std::endl;
	}
};