#ifndef USOCIAL_H
#define USOCIAL_H


#include <iostream>
#include <list>
#include <map>
#include <algorithm>
#include <exception>


class USocial
{
	std::string userName;
	bool isPrimum;
	std::map<unsigned long, User*> users;
public:
	friend class User;
	User* registerUser(const std::string& name, bool);
	User* registerUser(const std::string& name);

	void removeUser(User*);
	User* getUserById(unsigned long id);
	
};
#endif