#include <iostream>
#include "Media.h"


class Media
{
	virtual void display() = 0;
};
