#include <iostream>
#include <list>
#include <algorithm>
#include <exception>
#include <map>

#include "USocial.h"
#include "User.h"


User* USocial::registerUser(const std::string& name, bool isPrimum)
{
	this->userName = name;
	this->isPrimum = isPrimum;
}

User* USocial::registerUser(const std::string& name)
{
	return registerUser(name, false);
}

void USocial::removeUser(User*)
{

}
	
User* USocial::getUserById(unsigned long id)
{

}
