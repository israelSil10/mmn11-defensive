
class Audio : public Media
{
	void display();
};