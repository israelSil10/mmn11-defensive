#include <iostream>

class Media
{
	virtual void display() = 0;
};
