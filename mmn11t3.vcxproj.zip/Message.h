#include <iostream>
#include <list>
#include <algorithm>

class Message
{
public:
	std::string getText();
private:
	std::string text;
};