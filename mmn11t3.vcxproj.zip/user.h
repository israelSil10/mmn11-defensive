#ifndef USER_H
#define USER_H

#include <iostream>
#include <list>
#include <algorithm>
#include <exception>
#include "Post.h"
#include "Message.h"


class User
{
	
protected:
	unsigned long id = -1;
	std::string name;
	std::list<unsigned long> friends;
	std::list<Message*> receivedMsgs;
	User() {};
	~User() {};
public:
	unsigned long getId();
	std::string getName();
	std::list<Post*> getPosts();
	void addFriend(User*);
	void removeFriend(User*);
	void Post(std::string);
	void Post(std::string, Media*);
	//std::list<class pointer> func();
	//std::list<Post*> getPosts();
	void viewFriendsPosts();
	void receiveMsg(Message*);
	virtual void sendMsg(User*, Message);
	void viewReceivedMsgs();

	friend class USocial;

};

#endif