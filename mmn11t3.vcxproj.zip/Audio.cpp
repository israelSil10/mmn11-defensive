#include <iostream>
#include "Audio.h"
#include "Media.h"

class Audio : public Media
{
	void display() { std::cout << "Displaying audio" << std::endl; }
};