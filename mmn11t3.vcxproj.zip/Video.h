#include <iostream>

class Video : public Media
{
	void display();
};