#include <iostream>
#include "Media.h"

class Photo : public Media
{
	void display();
};
