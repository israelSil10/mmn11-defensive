#include <iostream>
#include "post.h"

class Post
{
public:
	Post(std::string text)
	{
		this->text = text;
	};

	Post(std::string text, Media* media)
	{
		this->text = text;
		this->media = media;

	};

	std::string getText()
	{
		return this->text;
	};
	Media* getMedia()
	{
		return this->media;
	};



private:
	std::string text;
	Media* media;

};

