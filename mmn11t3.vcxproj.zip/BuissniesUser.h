#include <iostream>

class buissniesUser : public User
{
	virtual void sendMsg(User*, Message);
};