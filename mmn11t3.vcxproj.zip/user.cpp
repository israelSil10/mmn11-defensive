#include <iostream>
#include <list>
#include <algorithm>
#include <exception>
#include "User.h"
#include "Message.h"


User::User()
{

}

User::~User()
{
	//delete();
}

unsigned long User::getId()
{

}

std::string User::getName()
{

}


void User::addFriend(User*)
{


}
void User::removeFriend(User*)
{

}
void User::Post(std::string)
{


}
void User::Post(std::string, Media*)
{


}

std::list<Post*> getPosts()
{


}

void User::viewFriendsPosts()
{


}

void receiveMsg(Message*)
{


}
void sendMsg(User*, Message)
{

}

void User::viewReceivedMsgs()
{

}
